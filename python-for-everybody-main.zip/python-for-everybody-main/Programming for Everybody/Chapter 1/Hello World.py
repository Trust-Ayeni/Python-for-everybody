# -*- coding: utf-8 -*-
"""
Created on Mon Oct 16 08:59:26 2017

@author: atse
"""

print("Hello World!")