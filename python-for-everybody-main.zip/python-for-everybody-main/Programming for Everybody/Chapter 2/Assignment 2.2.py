# -*- coding: utf-8 -*-
"""
Created on Mon Oct 16 09:00:05 2017

@author: atse
"""

name = input("Enter your name")
print("Hello %s" % name)