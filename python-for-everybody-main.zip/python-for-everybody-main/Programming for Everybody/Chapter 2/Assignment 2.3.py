# -*- coding: utf-8 -*-
"""
Created on Mon Oct 16 09:01:38 2017

@author: atse
"""

hrs = input("Enter Hours:")
rate = input("Enter Rate:")
cost = float(hrs)*float(rate)

print("Pay: %s" % cost)

