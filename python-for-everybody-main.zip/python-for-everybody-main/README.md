# Python-for-Everybody-Coursera
Coursera courses for the Python for Everybody Specialization by the University of Michigan.
